import pygame
import sys
import time
import pygame.freetype
from math import *

pygame.font.init()

Red = (255, 0, 0)
WIDTH = 1000
HEIGHT = 1000
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

font = pygame.font.Font(None, 74)

walls = []

start_time = time.time()

class Player:
    def __init__(self, image_path, start_x, start_y):
        self.image = pygame.image.load(image_path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (70, 70))
        self.rect = self.image.get_rect(center=(start_x, start_y))
        self.angle = 0 
        self.speed = 2

    def rotate(self, angle_change):
        self.angle += angle_change

    def move_forward(self):
        self.rect.x += self.speed * sin(radians(self.angle))
        self.rect.y -= self.speed * cos(radians(self.angle))

    def move_backward(self):
        self.rect.x -= self.speed * sin(radians(self.angle))
        self.rect.y += self.speed * cos(radians(self.angle))

    def draw(self, surface):
        rotated_image = pygame.transform.rotate(self.image, -self.angle)
        rotated_rect = rotated_image.get_rect(center=self.rect.center)
        surface.blit(rotated_image, rotated_rect.topleft)


skin = 'Audi.png'

player = Player(skin, 120, 500)
black_color = (0, 0, 0)
font = pygame.font.Font(None, 74)
loading = 0
game_state = 0


while True:
    screen.fill((47, 83, 155))

    if game_state == 0:
        text_surface = font.render("Нажмите Пробел чтобы начать", True, black_color)
        screen.blit(text_surface, (100, 250))
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_SPACE:
                    game_state = 1



    if game_state == 1:
        if loading ==0:
            with open('Map1.txt', 'r') as map:
                row, col = 0, 0
                for line in map.read().split('\n'):
                    x = list(line)
                    col = 0
                    for i in x:
                        if i == '1':
                            walls.append(pygame.Rect(col*20, row*20, 20, 20))
                            (row, col)
                        col += 1
                    row += 1
            loading += 1
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                sys.exit() 
                keys = pygame.key.get_pressed()
        
        keys = pygame.key.get_pressed()
        old_x = player.rect.x
        old_y = player.rect.y

        if keys[pygame.K_w]:
            player.rect.x += 6 * sin(radians(player.angle))
            player.rect.y -= 6 * cos(radians(player.angle))
        if keys[pygame.K_s]:
            player.rect.x -= 6 * sin(radians(player.angle))
            player.rect.y += 6 * cos(radians(player.angle))

        if keys[pygame.K_d]:
            player.rotate(3)
        if keys[pygame.K_a]:
            player.rotate(-3)

        for wall in walls:
            if player.rect.colliderect(wall):
                pygame.draw.rect(screen, (255, 255, 0), player.rect) #Включить чтобы посмотреть коллизии
                player.rect.x = old_x
                player.rect.y = old_y

        for wall in walls:
            pygame.draw.rect(screen, Red, wall)
        elapsed_time = int(time.time() - start_time)
        timer_text = font.render(str(elapsed_time), True, (0, 0, 0))
        screen.blit(timer_text, (50, 50))

        player.draw(screen)

    pygame.display.update()
    clock.tick(60)